import pandas as pd
import numpy as np
import random as random
from pretreatment import *
from divedandtest import *
def sigmod(xmat,w):
    m=-xmat*w
    return 1/(1+np.exp(m))
def gradientdescent(w,xmat,ymat,alpha=0.001,operate=sigmod):
    H=operate(xmat,w)#梯度下降法
    dw=xmat.T*(H-ymat)
    w=w-alpha*dw
    return w
def logicalturn(self,xmat,ymat,alpha=0.001,maxrenew=20000,operate=gradientdescent):
        #XMAT为mxn的矩阵，ymat为mx1的矩阵
        n=np.shape(xmat)[1]
        w=np.mat(np.random.randn(n,1))
        for i in range(maxrenew):
            w=operate(w,xmat,ymat,alpha)
        self.w=w
        return w
def loaddata(self,filename,n=1000,m=1):
        a=pd.read_csv(filename)#读取文件默认读取前n行第m列起
        a=a.values       
        x=a[:n,m:-1]
        y=a[:n,-1]
        return np.mat(x),np.mat(y).T
  
