
import pandas as pd
import numpy as np
import random as random
def twodivide(m1,m2):
    n1=np.median(m1,axis=0)
    n2=np.median(m2,axis=0)
    n=(n1+n2)/2#算的两个数据的中位数并取其平均数
    vfunc=np.vectorize(mapping)#将函数向量化
    for i in range(m1.shape[1]):
        m1[:,i]=vfunc(m1[:,i],n[i])
        m2[:,i]=vfunc(m2[:,i],n[i])
    return m1,m2
def delenan(data,dic=0):#删除缺失值
    return data.dropna()
def fillyourself(data,dic=0): #用字典或常数自定义输入值 
    return data.fillna(dic)
def fillmeans(data,dic=0):#填充平均值
    return data.fillna(data.mean())
def nanoprate(data,operate=delenan,dic=0):#传入的是一个dataframe格式的数据          
    return operate(data,dic)
class pretreatment():
    def __int__(self):
        return 0
    def onehot(self,datamat,index):#以index进行独热编码,index是一个列表
        return pd.get_dummies(datamat,prefix=index)
    def standardization(self,datamat):#标准差标准化
        u=np.mean(datamat,axis=0)
        std=np.std(datamat, axis=0)
        return (datamat-u)/std     
    def nanoperate(self,data,operate=delenan,dic=0):#传入的是一个dataframe格式的数据          
        return operate(data,dic)
    def Discretization(self,data,index,n=4):
    #输入一个dataframe，标签index和划分箱子数n
        data[index]=pd.cut(data[index],n)
        return data
    def threesigma(self,data,index):
    #传入一个dataframe数据，根据3∂原则处理异常值
        m=np.mean(data[index])
        n=m*3
        returnmat=data[abs(data[index]-m)<n]
        return returnmat
    def Tukeytest(self,data,index):#箱式法则
     #以index作为标准进行运算
        Percentile = np.percentile(data[index],[0,25,50,75,100])
     #求各个百分比代表的数
        IQR = Percentile[3] - Percentile[1]
        UpLimit = abs(Percentile[3]+IQR*1.5)
        DownLimit = abs(Percentile[1]-IQR*1.5)
     #分别求上下边界
        returnmat_1=data[data[index]>=Percentile[2]]
        returnmat_1=returnmat_1[returnmat_1[index]-Percentile[2]<=UpLimit]
        returnmat_2=data[data[index]<Percentile[2]]
        returnmat_2=returnmat_2[Percentile[2]-returnmat_2[index]<=DownLimit]
     #符合条件的代入
        return pd.concat([returnmat_1,returnmat_2])
    def autoNorm(self,dataset):#标准归一化数据
        minvalue=dataset.min(0)#取出每一列的最大值和最小值
        maxvalue=dataset.max(0)
        numrange=maxvalue-minvalue
        newdata=np.zeros(np.shape(dataset))#生成一个与dataset相同尺寸的数组
        newdata=newdata+dataset
        return (newdata-minvalue)/numrange#根据计算公式返回
    def similarity(self,data1,data2):
        #传入两个array
        m1=data1.copy()#传入两个array
        m2=data2.copy()
        twodivide(m1,m2)
        r=np.zeros(m1.shape[1])#创建两个零矩阵
        s=np.zeros(m1.shape[1])
        for i in range(m1.shape[1]):
            for j in range(m1.shape[0]):
                if m1[j,i]==0 and m2[j,i]==1:
                    s[i]+=1#记录data1中为1data2中为0的数量
                if m2[j,i]==0 and m1[j,i]==1:
                    r[i]+=1#记录data2中为1data1中为0的数量
        g=(r+s)/m1.shape[0]#计算相异性 
        g=1-g#计算相似性
        return g
##############################################################################
def onehot(datamat,index):#以index进行独热编码,index是一个列表
    return pd.get_dummies(datamat,prefix=index)
def standardization(datamat):#标准差标准化
    u=np.mean(datamat,axis=0)
    std=np.std(datamat, axis=0)
    return (datamat-u)/std     
def nanoperate(data,operate=delenan,dic=0):#传入的是一个dataframe格式的数据          
    return operate(data,dic)
def Discretization(data,index,n=4):
    #输入一个dataframe，标签index和划分箱子数n
    data[index]=pd.cut(data[index],n)
    return data
def threesigma(data,index):
    #传入一个dataframe数据，根据3∂原则处理异常值
    m=np.mean(data[index])
    n=m*3
    returnmat=data[abs(data[index]-m)<n]
    return returnmat
def Tukeytest(data,index):#箱式法则
     #以index作为标准进行运算
    Percentile = np.percentile(data[index],[0,25,50,75,100])
     #求各个百分比代表的数
    IQR = Percentile[3] - Percentile[1]
    UpLimit = abs(Percentile[3]+IQR*1.5)
    DownLimit = abs(Percentile[1]-IQR*1.5)
     #分别求上下边界
    returnmat_1=data[data[index]>=Percentile[2]]
    returnmat_1=returnmat_1[returnmat_1[index]-Percentile[2]<=UpLimit]
    returnmat_2=data[data[index]<Percentile[2]]
    returnmat_2=returnmat_2[Percentile[2]-returnmat_2[index]<=DownLimit]
     #符合条件的代入
    return pd.concat([returnmat_1,returnmat_2])
def autoNorm(dataset):#标准归一化数据
    minvalue=dataset.min(0)#取出每一列的最大值和最小值
    maxvalue=dataset.max(0)
    numrange=maxvalue-minvalue
    newdata=np.zeros(np.shape(dataset))#生成一个与dataset相同尺寸的数组
    newdata=newdata+dataset
    return (newdata-minvalue)/numrange#根据计算公式返回
def similarity(data1,data2):
    #传入两个array
    m1=data1.copy()#传入两个array
    m2=data2.copy()
    twodivide(m1,m2)
    r=np.zeros(m1.shape[1])#创建两个零矩阵
    s=np.zeros(m1.shape[1])
    for i in range(m1.shape[1]):
        for j in range(m1.shape[0]):
            if m1[j,i]==0 and m2[j,i]==1:
                s[i]+=1#记录data1中为1data2中为0的数量
            if m2[j,i]==0 and m1[j,i]==1:
                r[i]+=1#记录data2中为1data1中为0的数量
    g=(r+s)/m1.shape[0]#计算相异性 
    g=1-g#计算相似性
    return g