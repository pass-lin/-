import pandas as pd
import numpy as np
from divedandtest import *
import pretreatment as pre
def distance(dataset,testline,n=1):
    dataset=np.array(dataset)
    testline=np.array(testline)
    return np.sum((dataset-testline)**2,axis=n)**0.5
def randCent(dataset,k):
    n=np.shape(dataset)[1]
    minvalue=dataset.min(0)#取出每一列的最大值和最小值
    maxvalue=dataset.max(0)
    numrange=maxvalue-minvalue
    returnmat=np.zeros((k,n))#生成的随机矩阵范围要在最大值与最小值之间
    rand=np.random.random((k,n))
    returnmat=returnmat+minvalue+rand*numrange
    return returnmat
def kmeans(dataset,k=5,dist=distance,createCent=randCent):
        flag=1#是否继续迭代的标志
        m=np.shape(dataset)[0]#获得形状
        returnmat=np.mat(np.zeros((2,m)))#生成一个记录矩阵
        centroids=randCent(dataset,k)#生成k个随机簇
        dataset=np.mat(dataset)#矩阵化便于后续运算
        returnmat[1,:]=np.inf#距离初始化
        while flag:       
            flag=0
            minp=0
            for i in range(m):
                dismax=returnmat[1,i]#取出当前误差
                for j in range(k):#计算该点与每一个簇的误差，如果误差小于当前则更新数据
                    pointdist=dist(dataset[i],centroids[j])
                    if pointdist<dismax:
                        dismax=pointdist
                        minp=j
                if  dismax!=returnmat[1,i]:#只要有一个点进行了更新，那就要继续迭代下去
                    flag=1
                    returnmat[0,i]=minp
                    returnmat[1,i]=dismax
            for i in range(k) :#更新簇的数据
                ptsinclust = dataset[np.nonzero(returnmat[0,:].A == i)[1]]
                if len(ptsinclust):#只有这个簇含有数据时才更新
                    centroids[i]=np.mean(ptsinclust,axis=0)
        return centroids,returnmat
def loaddata(filename,n=1000,m=1):
        a=pd.read_csv(filename)#读取文件默认读取前n行第m列起
        a=a.values       
        return a[:n,m:-1],a[:n,-1]
def twokmeans(dataset,k=5,dist=distance):
    m=np.shape(dataset)[0]
    #建立一个2xm的矩阵，第一行存储归属，第二韩存储误差
    returnmat=np.mat(np.zeros((2,m)))
    centroids=[np.mean(dataset,axis=0)]
    for i in range(m):
        returnmat[1,i]=dist(dataset[i,:],centroids[0],0)
        #计算总误差
    n=1
    while(n<k):
        low=np.inf
        for i in range(n):
            #获得属于该簇的点
            dataproid=dataset[np.nonzero(returnmat[0,:].A==i)[1],:] 
            #新一轮划分
            newproid,splitdata=kmeans(dataproid,2)
            #计算划分误差
            splitr=np.sum(splitdata[:,1])
            oldr=np.sum(returnmat[1,np.nonzero(returnmat[0,:].A!=i)[1]])
            print(i,splitr,oldr)
            if oldr+splitr<low:
                #选择出误差最小的一个点
                low=oldr+splitr
                bestproid=newproid.copy()
                bestdivide=splitdata.copy()
                bestchar=i
        #更新簇
        centroids[bestchar]=bestproid[0]
        centroids.append(bestproid[1])
        j=0
        n=len(centroids)
        #更新点
        for i in range(m):
            if returnmat[0,i]==bestchar:                   
                if bestdivide[0,j]==1:
                      returnmat[0,i]=n-1
                returnmat[1,i]=bestdivide[1,j]
                j=j+1
    return centroids,returnmat

            
    
