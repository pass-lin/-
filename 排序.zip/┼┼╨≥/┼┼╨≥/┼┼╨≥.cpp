﻿#include"qgsort.h"
#include<stdlib.h>
#include<math.h>
#include<string.h>
#include"SqStack.h"
#include<stdio.h>
#include<time.h>
void screen()
{
	printf("********************************************************************\n");
	printf("***************      1:大数组测试             **********************\n");
	printf("***************      2:小数组测试             **********************\n");
	printf("***************      3:结束程序               **********************\n");
	printf("********************************************************************\n");
}
void select()
{
	printf("********************************************************************\n");
	printf("***************      1:插入排序               **********************\n");
	printf("***************      2:归并排序               **********************\n");
	printf("***************      3:快速排序               **********************\n");
	printf("***************      4:计数排序               **********************\n");
	printf("***************      5:基数计数排序           **********************\n");
	printf("***************      6:非递归快排             **********************\n");
	printf("***************      7:结束程序               **********************\n");
	printf("********************************************************************\n");
}

void largetest(char* filename)
{
	FILE* pFile;
	fopen_s(&pFile,filename, "w");
	int m,*p,k;
	printf("请输入你测试的数字数量\n");
	printf("[1]10000\n[2]50000\n[3]200000\n");
	scanf_s("%d", &m);
	switch (m)
	{
	case 1:k=10000; break;
	case 2:k=50000; break;
	case 3:k=200000; break;
	default:printf("输入错误结束程序\n"); return;
		break;
	}
	p = (int*)malloc(k * sizeof(int));
	select();
	printf("请输入你测试的排序方法\n");
	int endflag = 1; 
	int* temp;
	while (endflag)
	{
		srand((unsigned)time(NULL));
		for (int i = 0; i < k; i++)
			p[i] = rand();
		fprintf(pFile, "before insert:");
		for (int i = 0; i < k; i++)
			fprintf(pFile, "-->%d", p[i]);
		fprintf(pFile, "\n");
		scanf_s("%d", &m);
		clock_t start = clock();
		switch (m)
		{
		case 1:insertSort(p,k); break;
		case 2:temp = (int*)malloc(k * sizeof(int)); MergeSort(p, 0, (int)((0 + k - 1) / 2), k - 1, temp); free(temp); break;
		case 3:QuickSort_Recursion(p, 0, k - 1); break;
		case 4:CountSort(p, k, maxnum(p, k)); break;
		case 5:RadixCountSort(p, k); break;
		case 6:QuickSort(p, k); break;
		case 7:endflag = 0; break;
		default:printf("输入错误\n");
			break;
		}		
		clock_t diff = clock()-start;
		printf("用时为:%dms\n", diff);
		fprintf(pFile, "after insert:");
		for (int i = 0; i < k; i++)
			fprintf(pFile, "-->%d",p[i]);
		fprintf(pFile, "\n");
	}
	fclose(pFile);
	free(p);
}
void smalltest(char* filename)
{
	FILE* pFile;
	fopen_s(&pFile, filename, "w");
	int m, p[1000][100], k = 100;
	select();
	printf("请输入你测试的排序方法\n");
	int endflag = 1;
	int* temp;
	while (endflag)
	{
		scanf_s("%d", &m);
		srand((unsigned)time(NULL));
		for (int i = 0; i < 1000; i++)
			for (int j = 0; j < 100; j++)
				p[i][j] = rand();
		for (int i = 0; i < 1000; i++)
		{
			fprintf(pFile, "第%d个排序前", i);
			for (int j = 0; j < 100; j++)
				fprintf(pFile, "-->%d", p[i][j]);
			fprintf(pFile, "\n");
		}
		for (int i = 0; i < 1000; i++)
			fwrite(p[i], sizeof(int), sizeof(p[i]), pFile);
		clock_t start = clock();		
		switch (m)
		{
		case 1:
			for (int i = 0; i < 1000; i++)
				insertSort(p[i], k);
			break;
		case 2:temp = (int*)malloc(k * sizeof(int)); 
			for (int i = 0; i < 1000; i++)
				MergeSort(p[i], 0, (int)((0 + k - 1) / 2), k - 1, temp);
			free(temp); break;
		case 3:
			for (int i = 0; i < 1000; i++)
				QuickSort_Recursion(p[i], 0, k - 1);
			break;
		case 4:
			for (int i = 0; i < 1000; i++)
				CountSort(p[i], k, maxnum(p[i], k));
			break;
		case 5:
			for (int i = 0; i < 1000; i++)
				RadixCountSort(p[i], k);
			break;
		case 6:
			for (int i = 0; i < 1000; i++)
				QuickSort(p[i], k);
			break;
		case 7:endflag = 0; break;
		default:printf("输入错误\n");
			break;
		}		
		clock_t diff = clock() - start;
		printf("用时为:%dms\n", diff);
		for (int i = 0; i < 1000; i++)
		{
			fprintf(pFile, "第%d个排序后", i);
			for (int j = 0; j < 100; j++)
				fprintf(pFile, "-->%d", p[i][j]);
			fprintf(pFile, "\n");
		}
	}
}
int main()
{
	char filename[30];
	printf("请输入你要存储的文件名:");
	scanf_s("%s", filename, 30);
	int m;
	int endflag = 1;	
	while (endflag)
	{
		screen();
		printf("输入你的选择:");
		scanf_s("%d", &m);
		switch (m)
		{
		case 1:largetest(filename); break;
		case 2:smalltest(filename); break;
		case 3:endflag = 0; break;
		default:printf("输入错误\n");
			break;
		}
	}
	system("pause");
}