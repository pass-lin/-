import pandas as pd
import numpy as np
import random as random
from pretreatment import *
import divedandtest as dive
def standregerr(xarry,yarry):
    xmat=np.mat(xarry)#xy矩阵化
    ymat=np.mat(yarry).T
    xtx=xmat.T*xmat
    if np.linalg.det(xtx)==0:#行列式为零则报错
        print("error")
        return 0
    ws=xtx.I*xmat.T*ymat
    return ws#返回关键值
def standrun(test,datamat,k=1.0):
    xarry=datamat[:,:-1]
    yarry=datamat[:,-1]#y为m的最后一列
    w=standregerr(xarry,yarry)
    axi=np.arange(np.shape(test)[0])
    if np.sum(w)==0:
        return 0,0
    else:
        #为了方便test函数统一接口也返回一个axi，这里的axi是test全部元素的坐标
        return np.mat(test[:,:-1])*w,axi
def lwlr(testpoint,xarry,yarry,k):
    xmat=np.mat(xarry)#xy矩阵化
    ymat=np.mat(yarry).T
    m=np.shape(xmat)[0]
    weights=np.mat(np.eye(m))#建立一个单位阵
    for i in range(np.shape(xmat)[0]):
        diffmat=xmat[i]-testpoint#计算权重
        #核函数为:|xi-x|/-2k^2
        weights[i,i]=np.exp(abs(diffmat*diffmat.T)/(-2*(k**2)))
    xtx=xmat.T*weights*xmat
    if np.linalg.det(xtx)==0.0:
        print("error")
        return 0
    #计算该点的w
    ws=xtx.I*xmat.T*weights*ymat
    return ws
def lwlrrun(test,datamat,k=1.0):
    xarry=datamat[:,:-1]
    yarry=datamat[:,-1]#y为m的最后一列    
    m=np.shape(test)[0]
    yhat=np.zeros(m)
    axi=[]
    for i in range(m):
        w=lwlr(test[i,:-1],xarry,yarry,k)#计算对应的w
        #判断w计算过程中是否出现奇异矩阵
        #记录下正常运算的坐标并返回
        if np.sum(w)!=0:
            yhat[i]=np.mat(test[i,:-1])*w 
            axi.append(i)
    #返回预测值及在test中对应的坐标便于运算
    return yhat,np.array(axi)
def test(datatmat,m=10,k=5,running=lwlrrun,divide=dive.holdout,judge=dive.rpower):
        #传入测试数据集，重复测试次数m，划分方法和判断方法
        #测试数据集最后一列为结果y值
        num=0
        g=0
        for i in range(m):
            test,train=divide(datatmat)#划分训练集和测试集
            precast,axi=running(test,train,k)            
            if np.sum(precast)!=0:#进行运算和评估
                precast=precast.T
                num+=judge(test[axi,-1],precast)
                g+=1#记录有效运算的次数               
        return num/g#返回平均值
def loaddata(filename,n=100,m=1):
        a=pd.read_csv(filename)
        #读取文件默认读取前n行,从第m列开始读
        a=a.values
        d,b=np.shape(a)        
        k=np.ones((d,b-(m-1)))#建立一个axb全为一的矩阵
        k[:,m:]=a[:,m:]#x0列为一，其余为m的n-1列
        return k[:n,m:]    
def crosstest(datamat,n=10,k=5,running=standrun,divide=dive.holdout,judge=dive.rpower):
        m=np.shape(datamat)[0]
        R=set(range(m))#建立一个全部索引的集合
        klist=[]
        for i in range(n):
            temp=random.sample(R,int(len(R)/(k-i)))#随机取出总集合的1/k
            R=R.difference(temp)#总集合中删除添加的那部分
            klist.append(np.array(temp))#将新生成的数据加入klist
        R=set(range(m))#重新生成总集合
        num=0
        g=0
        for i in range(n):
            test=datamat[klist[i]]#逐步取第k份为测试集
            t=list(R.difference(klist[i]))#其余部分为训练集合
            train=datamat[t]
            precast,axi=running(test,train,k)
            if np.sum(precast)!=0:#进行运算和评估                
                precast=precast.T
                num+=judge(test[:,-1],precast)
                g+=1#记录有效运算的次数
        return num/g#返回平均值

