import pandas as pd
import numpy as np
import random as random
from pretreatment import *
from divedandtest import *
def knn(dataset,label,inx,k):
    #输入向量inx，训练向量dataset，前k个值，对应标签label
        dist=distance(dataset,inx)#计算距离
        sortlabel=dist.argsort()#排序取前k个
        beforek={}#定义一个字典
        for i in range(k):#统计前k个距离各自标签的数量
            beforek[label[sortlabel[i]]]=beforek.get(label[sortlabel[i]],0)+1
        returnvalue=sorted(beforek.items(),key=lambda item: item[1],reverse=True)
    #以键值进行排序
        return int(returnvalue[0][0])#返回预测值 
def loaddata(filename,n=1000,m=1):
        a=pd.read_csv(filename)#读取文件默认读取前n行第m列起
        a=a.values       
        return a[:n,m:]
def test(datatmat,k=10,divide=holdout,judge=accuracy,n=0.05):
        #传入测试数据集，重复测试次数k，划分方法和判断方法
        #测试数据集最后一列为结果y值
        #n为划分数据集的比例
        num=0
        for i in range(k):
            test,train=divide(datatmat,n)#划分训练集和测试集
            fre=[]
            for i in range(test.shape[0]):#把测试集逐个进行运算
                fre.append(knn(train[:,:-1],train[:,-1],test[i,:-1],20))
            fre=np.array(fre)           
            num+=judge(test[:,-1],fre,0.5,2)#计算精确值
        return num/k#返回平均值
def crosstest(datamat,k=10,divide=holdout,judge=accuracy,n=0.05):
        m=np.shape(datamat)[0]
        R=set(range(m))#建立一个全部索引的集合
        klist=[]
        for i in range(k):
            temp=random.sample(R,int(len(R)/(k-i)))#随机取出总集合的1/k
            R=R.difference(temp)#总集合中删除添加的那部分
            klist.append(np.array(temp))#将新生成的数据加入klist
        R=set(range(m))#重新生成总集合
        num=0
        for i in range(k):
            test=datamat[klist[i]]#逐步取第k份为测试集
            t=list(R.difference(klist[i]))#其余部分为训练集合
            train=datamat[t]
            fre=[]
            for i in range(test.shape[0]):#把测试集逐个进行运算
                fre.append(knn(train[:,:-1],train[:,-1],test[i,:-1],20))
            fre=np.array(fre)           
            num+=judge(test[:,-1],fre,0.5,2)#计算精确值
        return num/k#返回平均值

