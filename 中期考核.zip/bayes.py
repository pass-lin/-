import numpy as np
import random as random
def creatvocablist(data):
    #建立一个词表
    vocabset=set([])
    for i in data:
        #通过不断并集建立一个完整集合
        vocabset=vocabset|set(i)
    return list(vocabset)#返回的词表应该是
def setwordlist(vocablist,inputset):
    #建立一个空白向量
    returnlist=np.zeros(len(vocablist))    
    for word in inputset:
        if word in vocablist:
            #对应词典位置+1
            returnlist[vocablist.index(word)]+=1
        else:
            #词典无该数输出错误
            print("the word:"+word+ "is not in vocablist")
    return returnlist
def beyyestrain(train,label):
    #贝叶斯训练器
    #train为训练数据，label为对应标签
    numword=np.shape(train[0])
    #获得词向量的长度numword
    #获得标签的长度numtrain
    numtrain=np.shape(label)[0]
    #计算出总为1的概率
    pAbusive=sum(label)/len(label)
    p0Num=np.zeros(numword)
    p1Num=np.zeros(numword)
    #建立空向量
    p0,p1=0,0
    for i in range(numtrain):
        if label[i]==1:
            p1Num+=train[i]
            p1+=sum(train[i])
        else:
            p0Num+=train[i]
            p0+=sum(train[i])
    #为了避免出现log0的情况，P1num和p2num整体加一
    p1Vect=np.log(p1Num/p1+1)
    p0Vect=np.log(p0Num/p0+1)
    return p0Vect,p1Vect,pAbusive
def judge(test,p0Vect,p1Vect,pAbusive):
       p1=sum(p1Vect*test)+np.log(1+pAbusive)
       p0=sum(p0Vect*test)+np.log(2-pAbusive)
       if p1>p0:
           #由于垃圾邮件在现实中整体概率小于非垃圾邮件
           #所以只有p1>p0时才判断为垃圾邮件
           return 1
       return 0
def test(dataset,label,k=10,rate=0.2):
    data=np.array(dataset)
    m=len(data)
    num=0
    #训练出词表
    vocablist=creatvocablist(data)
    R=set(range(m))
    for i in range(m):
        #将每个文件都向量化
        data[i]=setwordlist(vocablist,data[i])    
    for i in range(k):        
        test=random.sample(R,int(m*rate))#随机取出总集合的1/k
        train=R.difference(test)#总集合中删除添加的那部分
        train=list(train)
        test=list(test)
        p0Vect,p1Vect,pAbusive=beyyestrain(data[train],label[train])
        for i in test:
            predict=judge(data[i],p0Vect,p1Vect,pAbusive)
            if predict==label[i]:
                num+=1#统计判断正确的数量
    return num/(k*int(m*rate))#返回准确度
#以下为打开文件的操作
j=1
data=[]
label=[]
while 1:
    path="ham\\"+str(j)+'.txt'
    sentence=[]
    try:
        f=open(path,'r')
        label.append(1)
        for i in f.readlines():
            sentence.extend(i.split())
        data.append(sentence)
        f.close()
        j=j+1
    except OSError:
        break
j=1
while 1:
    path="spam\\"+str(j)+'.txt'
    sentence=[]
    try:
        f=open(path,'r')
        label.append(0)
        for i in f.readlines():
            sentence.extend(i.split())
        data.append(sentence)
        f.close()
        j=j+1
    except OSError:
        break
label=np.array(label)
print('分类准确度为'+str(test(data,label)))
    
    
 