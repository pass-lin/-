import pandas as pd
import numpy as np
import random as random
import matplotlib.pyplot as plt
def ROC(truedata,forecastdata,threshold,twodivid):
    tpfn=sum(truedata)#计算正例数
    fptn=np.shape(truedata)[0]-tpfn#计算负例数
    m=np.argsort(-forecastdata)#升序排序
    forecastdata=forecastdata.copy()[m]
    truedata=truedata.copy()[m]
    tpr=1/tpfn#y轴走得单位距离
    fpr=1/fptn#x轴走得单位距离
    x=0
    y=0
    xarray=[]#存储绘图用的xy点
    yarray=[]
    for i in range(np.shape(truedata)[0]):
        if truedata[i]==1:
            y+=tpr#如果当前点是正例，则y走一单位距离
        else:
            x+=fpr#否则x走一单位距离
        xarray.append(x)
        yarray.append(y)
    plt.plot(xarray,yarray,linestyle='--',marker='x')#绘图
    for i in range(np.shape(truedata)[0]):
         plt.text(xarray[i],yarray[i],s=forecastdata[i])
def AUC(truedata,forecastdata,threshold,twodivid):
    tpfn=sum(truedata)#计算正例数
    fptn=np.shape(truedata)[0]-tpfn#计算负例数
    m=np.argsort(-forecastdata)#升序排序
    forecastdata=forecastdata.copy()[m]
    truedata=truedata.copy()[m]
    tpr=1/tpfn#y轴走得单位距离
    fpr=1/fptn#x轴走得单位距离
    x=0
    y=0
    xarray=[]#存储绘图用的xy点
    yarray=[]
    for i in range(np.shape(truedata)[0]):
        if truedata[i]==1:
            y+=tpr#如果当前点是正例，则y走一单位距离
        else:
            x+=fpr#否则x走一单位距离
        xarray.append(x)
        yarray.append(y)
    auc=0
    for i in range(0,np.shape(truedata)[0]-1):#根据AUC计算公式计算
        auc+=(xarray[i+1]-xarray[i])*(yarray[i]+yarray[i+1])
    auc=auc/2
    return auc

def accuracy(truedata,forecastdata,threshold=0.5,twodivid=1):#准确值
    #接口为真实值，预测值，阈值，和是否为二分类的预测数据
    if twodivid!=1:#如果不是二分类预测的数据，那么比较预测结果
        m=np.shape(truedata)[0]
        n=0        
        for i in range(m):
            n=n+int(truedata[i]==forecastdata[i])
        return n/m
    else:#如果是先进行二分的处理
        forecast=forecastdata.copy()
        forecast[forecast<threshold]=0
        forecast[forecast>=threshold]=1#某点概率为正大于等于阈值则为1，反之为0
        m=np.shape(truedata)[0]
        n=0
        for i in range(m):#随后进行比较
            n=n+int(truedata[i]==forecast[i])
        return n/m
def precision(truedata,forecastdata,threshold=0.5,twodivid=1):
    forecast=forecastdata.copy()#二分的处理
    forecast[forecast<threshold]=0
    forecast[forecast>=threshold]=1#某点概率为正大于等于阈值则为1，反之为0
    r=np.shape(truedata)[0]
    m=np.sum(forecast)#得到预测为正的数量
    n=0            
    for i in range(r):#随后进行比较
        n=n+int(truedata[i]==forecast[i]==1)#正确预测为正的加一
    return n/m
def recall(truedata,forecastdata,threshold=0.5,twodivid=1):
    forecast=forecastdata.copy()#二分的处理
    forecast[forecast<threshold]=0
    forecast[forecast>=threshold]=1#某点概率为正大于等于阈值则为1，反之为0
    r=np.shape(truedata)[0]
    m=np.sum(truedata)#得到真正为正的数量
    n=0            
    for i in range(r):#随后进行比较
        n=n+int(truedata[i]==forecast[i]==1)#正确预测为正的加一
    return n/m
def Fscore(truedata,forecastdata,threshold=0.5,twodivid=1):
    m=np.float(recall(truedata,forecastdata))
    n=np.float(precision(truedata,forecastdata))        
    return 1/m+1/n
def PR(truedata,forecastdata,threshold=0.5,twodivid=1):
    m=np.argsort(-forecastdata)#升序排序
    forecast=forecastdata.copy()[m]
    true=truedata.copy()[m]
    
    xarray=[]#存储绘图用的xy点
    yarray=[]
    for i in range(np.shape(truedata)[0]):
        if i==0:#第一个点应该是（0，1）
            xarray.append(0)
            yarray.append(1)
        else:#以当前值为阈值计算召回率和精确率
            xarray.append(recall(true,forecast,forecast[i]))
            yarray.append(precision(true,forecast,forecast[i]))  
    plt.plot(xarray,yarray,linestyle='--',marker='x')#绘图
def Variance(truedata,forecastdata):#方差
    m=np.mean(forecastdata,axis=0)
    return np.sum(np.power(m-forecastdata,2)/len(forecastdata))
def Bias(truedata,forecastdata):#偏差
    return np.sum(np.power(truedata-forecastdata,2)/len(truedata))
def MSE(truedata,forecastdata):
    return np.sum(np.power(truedata-forecastdata,2)/len(truedata))
def RMSE(truedata,forecastdata):
    m=np.sum(np.power(truedata-forecastdata,2)/len(truedata))
    return m**0.5
def MAE(truedata,forecastdata):
    m=abs(truedata-forecastdata)
    return np.sum(m)/len(truedata)
def MAPE(truedata,forecastdata):
    m=abs(truedata-forecastdata)/abs(truedata)
    return str(np.sum(m)/len(truedata)*100)+'%'
def rpower(truedata,forecastdata):#R平方
    m=np.mean(truedata,axis=0)
    ssr=np.power(truedata-forecastdata,2)
    sst=np.power(truedata-m,2)
    r2=np.sum(ssr)/np.sum(sst)
    return 1-r2
def holdout(data,k=0.3):
    ###传入一个array数据进行留出法划分数据集
    test=data.copy()
    n=test.shape[0]#获取数据集的形状
    R=range(0,n)
    r=random.sample(R,int(k*n))#生成一个随机数列表作为测试集的索引
    m=[]
    for i in R:#如果数i在测试集中，则不在训练集中
        if i not in r:
            m.append(i)
    train=test[r]#获得测试集
    test=test[m]#获得训练集
    return test,train
def bootstrapping(data,alpha=1):#自助法
    n=data.shape[0]#获取数据集的形状
    test=data.copy()
    m=range(0,n)
    R=set(m)
    k=pd.DataFrame(R)
    g=k.sample(n=n,replace=True)#随机抽取n个样本
    g=list(g.loc[:,0])
    d=set(g)#产生一个被抽取过的序列集合
    train=test[g]#训练集
    test=test[list(R.difference(d))]#测试集为未被抽取过得
    return test,train 
def mapping(a,m):#大于这个数则返回1，小于返回0
        return 1 if a>=m else 0
def loadfile(filename,n=100):
    m=pd.read_csv(filename)#读取文件默认读取前n行
    return m[:n]
def distance(dataset,testline,n=1):
    dataset=np.array(dataset)
    testline=np.array(testline)
    return np.sum((dataset-testline)**2,axis=n)**0.5#